package com.example.sdp1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.google.android.material.textfield.TextInputEditText
import com.google.firebase.auth.FirebaseAuth

class MainActivity : AppCompatActivity() {

    private lateinit var mAuth: FirebaseAuth
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        mAuth = FirebaseAuth.getInstance()
        val emailEditText = findViewById<EditText>(R.id.Username)
        val passwordEditText = findViewById<EditText>(R.id.Password4)
        val generateButton = findViewById<Button>(R.id.button)

        generateButton.setOnClickListener {
            mAuth.createUserWithEmailAndPassword(emailEditText.toString(),
                passwordEditText.toString()
            ).addOnCompleteListener {
                if (it.isSuccessful)
                    Toast.makeText(this, "User Created", Toast.LENGTH_SHORT).show()
                else
                    Toast.makeText(this, it.exception.toString(), Toast.LENGTH_SHORT).show()

            }
        }
    }
}